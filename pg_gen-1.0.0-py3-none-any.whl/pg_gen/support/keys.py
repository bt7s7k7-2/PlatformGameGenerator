from .Color import Color

KEY_COLORS = [Color.CYAN, Color.RED, Color.BLUE, Color.GREEN]
MAX_KEY_TYPE = len(KEY_COLORS)
