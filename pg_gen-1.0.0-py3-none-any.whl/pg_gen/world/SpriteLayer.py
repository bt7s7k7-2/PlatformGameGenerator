from enum import Enum


class SpriteLayer(Enum):
    NORMAL = 0
    BACKGROUND = 1
    GUI = 2
